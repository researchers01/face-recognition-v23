from tkinter import* 
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
from register import *
from main import *
from panel import AdminPanel


class Login:
    def __init__(self,root):
        self.root=root
        self.root.title("Login")
        self.root.geometry("1366x768+0+0")

        # variables 
        self.var_ssq=StringVar()
        self.var_sa=StringVar()
        self.var_pwd=StringVar()


        self.bg=ImageTk.PhotoImage(file=r"Images_GUI\loginBg1.jpg")
        
        lb1_bg=Label(self.root,image=self.bg)
        lb1_bg.place(x=0,y=0, relwidth=1,relheight=1)

        frame2= Frame(self.root,bg="#002B53")
        frame2.place(x=260,y=170,width=340,height=450)

        # img1=Image.open(r"Images_GUI\log1.png")
        # img1=img1.resize((100,100),Image.LANCZOS)
        # self.photoimage1=ImageTk.PhotoImage(img1)
        # lb1img1 = Label(image=self.photoimage1,bg="#002B53")
        # lb1img1.place(x=690,y=175, width=100,height=100)

        get_str = Label(frame2,text="TEACHER",font=("times new roman",20,"bold"),fg="white",bg="#002B53")
        get_str.place(x=100,y=100)

        #label1 
        username =lb1= Label(frame2,text="Email:",font=("times new roman",15,"bold"),fg="white",bg="#002B53")
        username.place(x=30,y=160)

        #entry1 
        self.txtuser=ttk.Entry(frame2,font=("times new roman",15,"bold"))
        self.txtuser.place(x=33,y=190,width=270)


        #label2 
        pwd =lb1= Label(frame2,text="Password:",font=("times new roman",15,"bold"),fg="white",bg="#002B53")
        pwd.place(x=30,y=230)

        #entry2 
        self.txtpwd=ttk.Entry(frame2, show='*',font=("times new roman",15,"bold"))
        self.txtpwd.place(x=33,y=260,width=270)


        # Creating Button Login
        loginbtn=Button(frame2,command=self.login,text="Login",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#002B53",bg="white",activeforeground="white",activebackground="#007ACC")
        loginbtn.place(x=33,y=320,width=270,height=35)


        # Creating Button Registration
        loginbtn=Button(frame2,command=self.reg,text="Register",font=("times new roman",10,"bold"),bd=0,relief=RIDGE,fg="white",bg="#002B53",activeforeground="orange",activebackground="#002B53")
        loginbtn.place(x=33,y=370,width=50,height=20)


        # Creating Button Forget
        loginbtn=Button(frame2,command=self.forget_pwd,text="Forget",font=("times new roman",10,"bold"),bd=0,relief=RIDGE,fg="white",bg="#002B53",activeforeground="orange",activebackground="#002B53")
        loginbtn.place(x=90,y=370,width=50,height=20)


        # admin login frame2
        frame2= Frame(self.root,bg="#002B53")
        frame2.place(x=760,y=170,width=340,height=450)

        # img1=Image.open(r"Images_GUI\log1.png")
        # img1=img1.resize((100,100),Image.LANCZOS)
        # self.photoimage1=ImageTk.PhotoImage(img1)
        # lb1img1 = Label(image=self.photoimage1,bg="#002B53")
        # lb1img1.place(x=690,y=175, width=100,height=100)

        get_str = Label(frame2,text="ADMIN",font=("times new roman",20,"bold"),fg="white",bg="#002B53")
        get_str.place(x=100,y=100)

        #label1 
        username =lb1= Label(frame2,text="Email:",font=("times new roman",15,"bold"),fg="white",bg="#002B53")
        username.place(x=30,y=160)

        #entry1 
        self.admintxtuser=ttk.Entry(frame2,font=("times new roman",15,"bold"))
        self.admintxtuser.place(x=33,y=190,width=270)


        #label2 
        pwd =lb1= Label(frame2,text="Password:",font=("times new roman",15,"bold"),fg="white",bg="#002B53")
        pwd.place(x=30,y=230)

        #entry2 
        self.admintxtpwd=ttk.Entry(frame2, show='*',font=("times new roman",15,"bold"))
        self.admintxtpwd.place(x=33,y=260,width=270)


        # Creating Button Login
        adminloginbtn=Button(frame2,command=self.adminlogin,text="Login",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#002B53",bg="white",activeforeground="white",activebackground="#007ACC")
        adminloginbtn.place(x=33,y=320,width=270,height=35)


        # Creating Button Registration
        # loginbtn=Button(frame2,command=self.reg,text="Register",font=("times new roman",10,"bold"),bd=0,relief=RIDGE,fg="white",bg="#002B53",activeforeground="orange",activebackground="#002B53")
        # loginbtn.place(x=33,y=370,width=50,height=20)


        # Creating Button Forget
        # loginbtn=Button(frame2,command=self.forget_pwd,text="Forget",font=("times new roman",10,"bold"),bd=0,relief=RIDGE,fg="white",bg="#002B53",activeforeground="orange",activebackground="#002B53")
        # loginbtn.place(x=50,y=370,width=50,height=20)




    #  THis function is for open register window
    def reg(self):
        self.root.withdraw()
        self.new_window=Toplevel(self.root)
        self.app=Register(self.new_window)


    def login(self):
        if (self.txtuser.get()=="" or self.txtpwd.get()==""):
            messagebox.showerror("Error","All Field Required!")
    
        else:
            # messagebox.showerror("Error","Please Check Username or Password !")
            conn = mysql.connector.connect(username='root', password='',host='localhost',database='face_recognition')
            mycursor = conn.cursor()
            mycursor.execute("select * from regteach where email=%s and pwd=%s",(
                self.txtuser.get(),
                self.txtpwd.get()
            ))
            row=mycursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Invalid Username and Password!")
            else:
                open_min=messagebox.askyesno("Yes or No","Access only Techers")
                if open_min>0:
                    self.new_window=Toplevel(self.root)
                    self.app=MainApp(self.new_window)
                    self.root.withdraw()
                else:
                    if not open_min:
                        return
            conn.commit()
            conn.close()

    # login function for admin
    def adminlogin(self):
        if (self.admintxtuser.get()=="" or self.admintxtpwd.get()==""):
            messagebox.showerror("Error","All Field Required!")
        elif(self.admintxtuser.get()=="admin" and self.admintxtpwd.get()=="admin"):
            messagebox.showinfo("Sussessfully","Welcome to Attendance Managment System Using Facial Recognition")
    
        else:
            # messagebox.showerror("Error","Please Check Username or Password !")
            conn = mysql.connector.connect(username='root', password='',host='localhost',database='face_recognition')
            mycursor = conn.cursor()
            mycursor.execute("select * from admin where email=%s and pwd=%s",(
                self.admintxtuser.get(),
                self.admintxtpwd.get()
            ))
            row=mycursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Invalid Username and Password!")
            else:
                open_min=messagebox.askyesno("Yes or No","Access only Admin")
                if open_min>0:
                    self.new_window=Toplevel(self.root)
                    self.app=AdminPanel(self.new_window)
                    self.root.withdraw()
                else:
                    if not open_min:
                        return
            conn.commit()
            conn.close()



# =====================Forget window=========================================
    
 
    def forget_pwd(self):
        if self.txtuser.get()=="":
            messagebox.showerror("Error","Please Enter the Email ID to reset Password!")
        else:
            self.root.withdraw()
            conn = mysql.connector.connect(username='root', password='',host='localhost',database='face_recognition')
            mycursor = conn.cursor()
            query=("select * from regteach where email=%s")
            value=(self.txtuser.get(),)
            mycursor.execute(query,value)
            row=mycursor.fetchone()
            # print(row)

            if row==None:
                messagebox.showerror("Error","Please Enter the Valid Email ID!")
            else:
                conn.close()
                self.root2=Toplevel()
                
                self.root2.title("Forget Password")
                self.root2.geometry("1366x768+0+0")
                l=Label(self.root2,text="Forget Password",font=("times new roman",30,"bold"),fg="#002B53",bg="#fff")
                l.place(x=0,y=10,relwidth=1)
                # -------------------fields-------------------
                #label1 
                ssq =lb1= Label(self.root2,text="Select Security Question:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
                ssq.place(x=70,y=80)

                #Combo Box1
                self.combo_security = ttk.Combobox(self.root2,textvariable=self.var_ssq,font=("times new roman",15,"bold"),state="readonly")
                self.combo_security["values"]=("Select","Your Date of Birth","Your Nick Name","Your Favorite Book")
                self.combo_security.current(0)
                self.combo_security.place(x=70,y=110,width=270)


                #label2 
                sa =lb1= Label(self.root2,text="Security Answer:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
                sa.place(x=70,y=150)

                #entry2 
                self.txtpwd=ttk.Entry(self.root2,textvariable=self.var_sa,font=("times new roman",15,"bold"))
                self.txtpwd.place(x=70,y=180,width=270)

                #label2 
                new_pwd =lb1= Label(self.root2,text="New Password:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
                new_pwd.place(x=70,y=220)

                #entry2 
                self.new_pwd=ttk.Entry(self.root2,textvariable=self.var_pwd,font=("times new roman",15,"bold"))
                self.new_pwd.place(x=70,y=250,width=270)

                # Creating Button New Password
                loginbtn=Button(self.root2,command=self.reset_pass,text="Reset Password",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#fff",bg="#002B53",activeforeground="white",activebackground="#007ACC")
                loginbtn.place(x=70,y=300,width=270,height=35)

#=======================Reset Passowrd Function=============================
    def reset_pass(self):
        if self.var_ssq.get()=="Select":
            messagebox.showerror("Error","Select the Security Question!",parent=self.root2)
        elif(self.var_sa.get()==""):
            messagebox.showerror("Error","Please Enter the Answer!",parent=self.root2)
        elif(self.var_pwd.get()==""):
            messagebox.showerror("Error","Please Enter the New Password!",parent=self.root2)
        else:
            conn = mysql.connector.connect(username='root', password='',host='localhost',database='face_recognition')
            mycursor = conn.cursor()
            query=("select * from regteach where email=%s and ssq=%s and sa=%s")
            value=(self.txtuser.get(),self.var_ssq.get(),self.var_sa.get())
            mycursor.execute(query,value)
            row=mycursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Please Enter the Correct Answer!",parent=self.root2)
            else:
                self.root2.withdraw()
                query=("update regteach set pwd=%s where email=%s")
                value=(self.var_pwd.get(),self.txtuser.get())
                mycursor.execute(query,value)
                conn.commit()
                conn.close()
                messagebox.showinfo("Info","Successfully Your password has been rest, Please login with new Password!",parent=self.root2)
            
                self.new_window=Toplevel(self.root)
                self.app=Login(self.new_window)
                



from tkinter import* 
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector

class Register:
    def __init__(self,root):
        self.root=root
        self.root.title("Register")
        self.root.geometry("1366x768+0+0")

        # ============ Variables =================
        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_cnum=StringVar()
        self.var_email=StringVar()
        self.var_ssq=StringVar()
        self.var_sa=StringVar()
        self.var_pwd=StringVar()
        self.var_cpwd=StringVar()
        self.var_check=IntVar()

        self.bg=ImageTk.PhotoImage(file=r"Images_GUI\bgReg.jpg")
        
        lb1_bg=Label(self.root,image=self.bg)
        lb1_bg.place(x=0,y=0, relwidth=1,relheight=1)

        frame= Frame(self.root,bg="#F2F2F2")
        frame.place(x=200,y=80,width=900,height=580)
        

        # img1=Image.open(r"Images_GUI\reg1.png")
        # img1=img1.resize((450,100),Image.LANCZOS)
        # self.photoimage1=ImageTk.PhotoImage(img1)
        # lb1img1 = Label(image=self.photoimage1,bg="#F2F2F2")
        # lb1img1.place(x=300,y=100, width=500,height=100)
        

        get_str = Label(frame,text="Registration",font=("times new roman",30,"bold"),fg="#002B53",bg="#F2F2F2")
        get_str.place(x=350,y=130)

        #label1 
        fname =lb1= Label(frame,text="First Name:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        fname.place(x=100,y=200)

        #entry1 
        self.txtuser=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",15,"bold"))
        self.txtuser.place(x=103,y=225,width=270)


        #label2 
        lname =lb1= Label(frame,text="Last Name:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        lname.place(x=100,y=270)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_lname,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=103,y=295,width=270)

        # ==================== section 2 -------- 2nd Columan===================

        #label1 
        cnum =lb1= Label(frame,text="Contact No:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        cnum.place(x=530,y=200)

        #entry1 
        self.txtuser=ttk.Entry(frame,textvariable=self.var_cnum,font=("times new roman",15,"bold"))
        self.txtuser.place(x=533,y=225,width=270)


        #label2 
        email =lb1= Label(frame,text="Email:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        email.place(x=530,y=270)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=533,y=295,width=270)

        # ========================= Section 3 --- 1 Columan=================

        #label1 
        ssq =lb1= Label(frame,text="Select Security Question:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        ssq.place(x=100,y=350)

        #Combo Box1
        self.combo_security = ttk.Combobox(frame,textvariable=self.var_ssq,font=("times new roman",15,"bold"),state="readonly")
        self.combo_security["values"]=("Select","Your Date of Birth","Your Nick Name","Your Favorite Book")
        self.combo_security.current(0)
        self.combo_security.place(x=103,y=375,width=270)


        #label2 
        sa =lb1= Label(frame,text="Security Answer:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        sa.place(x=100,y=420)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_sa,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=103,y=445,width=270)

        # ========================= Section 4-----Column 2=============================

        #label1 
        pwd =lb1= Label(frame,text="Password:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        pwd.place(x=530,y=350)

        #entry1 
        self.txtuser=ttk.Entry(frame,show='*',textvariable=self.var_pwd,font=("times new roman",15,"bold"))
        self.txtuser.place(x=533,y=375,width=270)


        #label2 
        cpwd =lb1= Label(frame, text="Confirm Password:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        cpwd.place(x=530,y=420)

        #entry2 
        self.txtpwd=ttk.Entry(frame,show='*',textvariable=self.var_cpwd,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=533,y=445,width=270)

        # Checkbutton
        # checkbtn = Checkbutton(frame,variable=self.var_check,text="I Agree the Terms & Conditions",font=("times new roman",13,"bold"),fg="#002B53",bg="#F2F2F2")
        # checkbtn.place(x=100,y=480,width=270)


        self.terms_text = (
           
"Terms and Conditions\n"

"1. Acceptance of Terms\n"
"By using this software, you agree to be bound by these terms and conditions.\n"

"2. Use of the Software\n"
"You are granted a non-exclusive, non-transferable license to use the software for personal or commercial purposes.\n"

"3. Restrictions\n"
"You may not modify, adapt, reverse engineer, decompile, or disassemble the software.\n"

"4. Intellectual Property\n"
"All intellectual property rights in the software are owned by the developer.\n"

"5. Warranty Disclaimer\n"
"The software is provided without any warranty, express or implied.\n"

"6. Limitation of Liability\n"
"The developer shall not be liable for any direct, indirect, incidental, special, or consequential damages.\n"

"7. Governing Law\n"
"These terms and conditions are governed by the laws of [your jurisdiction].\n"

"8. Changes to Terms\n"
"The developer reserves the right to update these terms and conditions at any time.\n"

"9. Contact Information\n"
"For questions or concerns regarding these terms, please contact [your contact information].\n"

)
        
        essay_widget = Text(wrap="word", width=180, height=30,  font=("verdana", 12, "bold"), fg="black")
        essay_widget.insert("135.5", self.terms_text)

        self.terms_popup = tk.Toplevel(root)
        self.terms_popup.title("Terms and Conditions")
        self.terms_popup.withdraw()  # Hide the popup initially

        self.terms_text_widget = tk.Text(self.terms_popup, wrap=tk.WORD, height=20, width=70, font=("verdana",13,"bold"),fg="black",highlightthickness=-1)
        self.terms_text_widget.pack(padx=10, pady=10)
        self.terms_text_widget.insert(tk.END, self.terms_text)

        self.checkbtn = tk.Checkbutton(self.terms_popup, text="I agree to the terms", variable=self.var_check)
        self.checkbtn.pack()

        # Bind the X button (closing) to the hide_terms method
        self.terms_popup.protocol("WM_DELETE_WINDOW", self.hide_terms)

        self.show_button = tk.Button(frame, text="Show Terms", command=self.show_terms,font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#fff",bg="#002B53",activeforeground="white",activebackground="#007ACC")
        self.show_button.place(x=103,y=480,width=270)

   

        # Creating Button Register
        loginbtn=Button(frame,command=self.reg,text="Register",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#fff",bg="#002B53",activeforeground="white",activebackground="#007ACC")
        loginbtn.place(x=103,y=520,width=270,height=35)

        # Creating Button Login
        loginbtn=Button(frame,command=self.login,text="Login",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#fff",bg="#002B53",activeforeground="white",activebackground="#007ACC")
        loginbtn.place(x=533,y=520,width=270,height=35)


    def login(self):
        self.root.withdraw()
        self.new_window=Toplevel(self.root)
        self.app=Login(self.new_window)

    def show_terms(self):
        self.terms_popup.deiconify()  # Show the popup
        self.show_button.config(state=tk.DISABLED)

    def hide_terms(self):   
        self.terms_popup.withdraw()  # Hide the popup
        self.show_button.config(state=tk.NORMAL)

    def reg(self):
        if (
            self.var_fname.get() == ""
            or self.var_lname.get() == ""
            or self.var_cnum.get() == ""
            or self.var_email.get() == ""
            or self.var_ssq.get() == "Select"
            or self.var_sa.get() == ""
            or self.var_pwd.get() == ""
            or self.var_cpwd.get() == ""
        ):
            messagebox.showerror("Error", "All Field Required!")
        elif self.var_pwd.get() != self.var_cpwd.get():
            messagebox.showerror("Error", "Please Enter Password & Confirm Password are Same!")
        elif self.var_check.get() == 0:
            messagebox.showerror("Error", "Please Check the Agree Terms and Conditions!")
        else:
            messagebox.showinfo("Successfully", "Successfully Register!")
            try:
                conn = mysql.connector.connect(
                    user="root", password="", host="localhost", database="face_recognition"
                )
                mycursor = conn.cursor()
                query = "SELECT * FROM regteach WHERE email=%s"
                value = (self.var_email.get(),)
                mycursor.execute(query, value)
                row = mycursor.fetchone()
                if row is not None:
                    messagebox.showerror("Error", "User already exists, please try another email")
                else:
                    insert_query = "INSERT INTO regteach (fname, lname, cnum, email, ssq, sa, pwd) VALUES (%s, %s, %s, %s, %s, %s, %s)"
                    insert_values = (
                        self.var_fname.get(),
                        self.var_lname.get(),
                        self.var_cnum.get(),
                        self.var_email.get(),
                        self.var_ssq.get(),
                        self.var_sa.get(),
                        self.var_pwd.get(),
                    )

                    mycursor.execute(insert_query, insert_values)

                    open_min = messagebox.askyesno("Yes or No", "Please Login")

                    if open_min > 0:
                        self.new_window = Toplevel(self.root)
                        self.app = Login(self.new_window)
                        self.root.withdraw()
                    else:
                        if not open_min:
                            return
                    conn.commit()
                    conn.close()

            except Exception as es:
                messagebox.showerror("Error", f"Due to: {str(es)}", parent=self.root)







if __name__ == "__main__":
    root=Tk()
    app=Login(root)
    root.mainloop()


